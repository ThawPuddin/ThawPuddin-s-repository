﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace 自行车租赁系统
{
    public partial class 会员注册 : Form
    {
        public 会员注册()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)//提交 会员注册
        {
            string id = textBox1.Text.Trim();
            string pwd = textBox2.Text.Trim();
            string name = textBox3.Text.Trim();
            string phone = textBox4.Text.Trim();
            string s = string.Format("insert into 会员表(账号,密码,姓名,电话) values('{0}','{1}','{2}','{3}')", id, pwd, name, phone);
            if (id == "" || pwd == "" || name == "" || phone == "")
            {
                MessageBox.Show("有选项为空，请填写完整注册信息");
            }
            else
            {
                if (SqlHelper.ExecuteNonQuery(s) > 0)
                {
                    MessageBox.Show("注册成功");
                    this.Close();
                    Login form = new Login();
                    form.Show();
                } this.Hide();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Login form = new Login();
            form.Show();
            this.Hide();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
